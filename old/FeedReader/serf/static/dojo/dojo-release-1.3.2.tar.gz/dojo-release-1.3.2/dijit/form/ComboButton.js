/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dijit.form.ComboButton"]){
dojo._hasResource["dijit.form.ComboButton"]=true;
dojo.provide("dijit.form.ComboButton");
dojo.require("dijit.form.Button");
}
