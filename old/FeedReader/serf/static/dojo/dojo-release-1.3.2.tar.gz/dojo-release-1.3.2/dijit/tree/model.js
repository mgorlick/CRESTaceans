/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dojo.declare("dijit.tree.model",null,{destroy:function(){
},getRoot:function(_1){
},mayHaveChildren:function(_2){
},getChildren:function(_3,_4){
},getIdentity:function(_5){
},getLabel:function(_6){
},newItem:function(_7,_8){
},pasteItem:function(_9,_a,_b,_c){
},onChange:function(_d){
},onChildrenChange:function(_e,_f){
}});
